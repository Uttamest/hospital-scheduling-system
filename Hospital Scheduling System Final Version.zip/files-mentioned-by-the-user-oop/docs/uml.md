# UML Class Diagram

```mermaid
classDiagram
    direction LR

    class Person {
        <<abstract>>
        -int id
        -string name
        -string phone
        +getId() int
        +getName() string
        +getPhone() string
        +setName(string) void
        +setPhone(string) void
        +role()* string
        +printSummary(ostream&)* void
        +serialize()* string
    }

    class Doctor {
        -string specialization
        +getSpecialization() string
        +setSpecialization(string) void
        +role() string
        +printSummary(ostream&) void
        +serialize() string
        +deserialize(string) Doctor
    }

    class Patient {
        -int age
        -string medicalNote
        +getAge() int
        +getMedicalNote() string
        +setAge(int) void
        +setMedicalNote(string) void
        +role() string
        +printSummary(ostream&) void
        +serialize() string
        +deserialize(string) Patient
    }

    class Appointment {
        -int id
        -int doctorId
        -int patientId
        -string date
        -string time
        -string reason
        -AppointmentStatus status
        +isActive() bool
        +dateTimeKey() string
        +cancel() void
        +printSummary(ostream&, string, string) void
        +serialize() string
        +deserialize(string) Appointment
    }

    class UserAccount {
        -int id
        -string username
        -string passwordHash
        -UserRole role
        -int linkedPersonId
        -bool active
        +getUsername() string
        +getRole() UserRole
        +getLinkedPersonId() int
        +isAdmin() bool
        +isReceptionist() bool
        +isDoctor() bool
        +isPatient() bool
        +printSummary(ostream&) void
        +serialize() string
        +deserialize(string) UserAccount
    }

    class AuthService {
        -string usersFile
        -vector~UserAccount~ users
        +load() void
        +save() void
        +login(string, string) UserAccount
        +validateNewCredentials(string, string) void
        +registerUser(string, string, UserRole, int) int
        +registerPatient(string, string, int) int
        +listUsers(ostream&) void
    }

    class Scheduler {
        -vector~Doctor~ doctors
        -vector~Patient~ patients
        -vector~Appointment~ appointments
        -DataStore dataStore
        +load() void
        +save() void
        +doctorExists(int) bool
        +patientExists(int) bool
        +addDoctor(string, string, string) int
        +addPatient(string, string, int, string) int
        +createAppointment(int, int, string, string, string) int
        +cancelAppointment(int) void
        +cancelPatientAppointment(int, int) void
        +listDoctorSchedule(int, ostream&) void
        +listPatientSchedule(int, ostream&) void
        +listAllPeoplePolymorphic(ostream&) void
    }

    class DataStore {
        -string doctorsFile
        -string patientsFile
        -string appointmentsFile
        +load(vector~Doctor~, vector~Patient~, vector~Appointment~) void
        +save(vector~Doctor~, vector~Patient~, vector~Appointment~) void
    }

    class DateTime {
        +isValidDate(string) bool
        +isValidTime(string) bool
        +requireValidDate(string) void
        +requireValidTime(string) void
        +key(string, string) string
    }

    class HospitalException
    class ValidationException
    class NotFoundException
    class ScheduleConflictException

    Person <|-- Doctor
    Person <|-- Patient
    Scheduler o-- Doctor
    Scheduler o-- Patient
    Scheduler o-- Appointment
    Scheduler o-- DataStore
    AuthService o-- UserAccount
    UserAccount --> Doctor : linkedPersonId
    UserAccount --> Patient : linkedPersonId
    Appointment --> Doctor : doctorId
    Appointment --> Patient : patientId
    DataStore ..> Doctor : load/save
    DataStore ..> Patient : load/save
    DataStore ..> Appointment : load/save
    DateTime ..> Appointment : validates
    HospitalException <|-- ValidationException
    HospitalException <|-- NotFoundException
    HospitalException <|-- ScheduleConflictException
```
