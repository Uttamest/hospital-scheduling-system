# Hospital Scheduling System

OOP II Final Project: a secure CLI-based hospital appointment management system built in C++.

This upgraded version works more like a real hospital scheduling desk. It includes patient signup, login, role-based access, doctor/patient records, appointment booking and cancellation, file storage, custom exceptions, runtime polymorphism, and a Makefile/build script for easier compilation.

## Team Members And Responsibilities

| No. | Name | Role | Main Responsibility |
| --- | --- | --- | --- |
| 1 | SHRESTHA UTTAM | Team Leader | Project leadership, GitHub setup, final integration, CLI menus, input handling, authentication menu flow, Makefile/build setup, and final quality check |
| 2 | RAI SURAJ | Models/OOP Classes | OOP model classes, inheritance, abstraction, polymorphism support, appointment model structure, and user account model support |
| 3 | KHADKA SANTOSH | Scheduling Logic | Appointment scheduling rules, appointment cancellation, conflict checking, and doctor/patient schedule viewing logic |
| 4 | KHAND THAKURI SHRADDHA | File I/O, Docs, UML, Testing | File save/load system, sample data files, UML diagram, README support, authentication data file, and testing |

## Team Leader Contribution

SHRESTHA UTTAM is the team leader and connects all parts of the project into one complete working system. His contribution includes:

- Managing the project structure and GitHub workflow
- Building the main CLI flow and role-based login screens
- Handling input validation and user interaction
- Integrating authentication, scheduling, OOP models, and file I/O
- Setting up PowerShell, Makefile, and VS Code build support
- Running final build tests and checking submission files

## Demo Login Accounts

The project includes demo users in `data/users.txt`. Passwords are stored as hashes, not plain text.

| Role | Username | Password | Access |
| --- | --- | --- | --- |
| Admin | `admin` | `Admin@123` | Full system access and user account management |
| Receptionist | `reception` | `Staff@123` | Doctors, patients, appointments, schedules |
| Doctor | `drlee` | `Doctor@123` | Doctor portal linked to Doctor ID 2 |
| Patient | `maya` | `Patient@123` | Patient portal linked to Patient ID 1 |

## Main Features

- Login and patient signup
- Role-based access for Admin, Receptionist, Doctor, and Patient
- Admin user account management
- Add and list doctors
- Add and list patients
- Create appointments
- Cancel appointments
- Patients can book/cancel only their own appointments
- Doctors can view their own schedules
- Receptionists can manage scheduling workflows
- Appointment conflict checking prevents double-booking
- Records are saved and reloaded using text files
- Runtime polymorphism demo through the abstract `Person` base class
- Custom exceptions for validation, not-found errors, and schedule conflicts

## OOP Concepts Used

- **Classes and objects:** doctors, patients, appointments, user accounts, scheduler, authentication service, and data storage are represented as classes.
- **Encapsulation:** class fields are private and accessed through public methods.
- **Inheritance:** `Doctor` and `Patient` inherit from the abstract `Person` class.
- **Abstraction:** `Person` defines pure virtual functions such as `role()`, `printSummary()`, and `serialize()`.
- **Runtime polymorphism:** `Scheduler::listAllPeoplePolymorphic()` stores doctors and patients as `const Person*` and calls virtual functions.
- **Composition:** `Scheduler` owns doctors, patients, appointments, and `DataStore`; `AuthService` owns user accounts.
- **Custom exceptions:** `HospitalException`, `ValidationException`, `NotFoundException`, and `ScheduleConflictException`.
- **File I/O:** doctors, patients, appointments, and user accounts are saved to and loaded from files.

## Exact File Upload And Ownership Plan

Each team member should upload or commit the files assigned to them from their own GitHub account/branch. This makes contribution visible.

### 1. SHRESTHA UTTAM - Team Leader, CLI, Authentication Flow, Build Setup

```text
.gitignore
.vscode/settings.json
.vscode/tasks.json
Makefile
build.ps1
src/main.cpp
include/InputUtils.h
src/InputUtils.cpp
README.md
```

Suggested branch:

```text
uttam-team-leader-cli-auth
```

Suggested commits:

```text
Set up project structure and build files
Add login screen and role-based CLI menus
Integrate authentication scheduling and file IO
Finalize README and submission checklist
```

### 2. RAI SURAJ - Models/OOP Classes

```text
include/Person.h
include/Doctor.h
include/Patient.h
include/Appointment.h
include/UserAccount.h
include/HospitalException.h
include/DateTime.h
include/TextUtils.h
src/Person.cpp
src/Doctor.cpp
src/Patient.cpp
src/Appointment.cpp
src/UserAccount.cpp
src/DateTime.cpp
src/TextUtils.cpp
```

Suggested branch:

```text
suraj-oop-models
```

Suggested commits:

```text
Add Person Doctor and Patient model classes
Add Appointment and UserAccount models
Add validation helpers and model comments
```

### 3. KHADKA SANTOSH - Scheduling Logic

```text
include/Scheduler.h
src/Scheduler.cpp
```

Suggested branch:

```text
santosh-scheduling-logic
```

Suggested commits:

```text
Add scheduler class and appointment creation logic
Add appointment conflict checking
Add role-safe appointment cancellation and schedule views
```

### 4. KHAND THAKURI SHRADDHA - File I/O, Docs, UML, Testing

```text
include/DataStore.h
include/AuthService.h
src/DataStore.cpp
src/AuthService.cpp
data/doctors.txt
data/patients.txt
data/appointments.txt
data/users.txt
docs/uml.md
docs/uml.mmd
README.md
```

Suggested branch:

```text
shraddha-fileio-docs-testing
```

Suggested commits:

```text
Add file input output support
Add authentication file storage and demo users
Update UML diagram and test workflows
```

## Files To Upload To GitHub

Upload these files and folders:

```text
README.md
Makefile
build.ps1
.gitignore
.vscode/
data/
docs/
include/
src/
```

Do not upload generated files:

```text
build/
*.exe
*.o
*.obj
```

## Complete Project File List

```text
.
|-- .gitignore
|-- .vscode/
|   |-- settings.json
|   `-- tasks.json
|-- Makefile
|-- README.md
|-- build.ps1
|-- data/
|   |-- appointments.txt
|   |-- doctors.txt
|   |-- patients.txt
|   `-- users.txt
|-- docs/
|   |-- uml.md
|   `-- uml.mmd
|-- include/
|   |-- Appointment.h
|   |-- AuthService.h
|   |-- DataStore.h
|   |-- DateTime.h
|   |-- Doctor.h
|   |-- HospitalException.h
|   |-- InputUtils.h
|   |-- Patient.h
|   |-- Person.h
|   |-- Scheduler.h
|   |-- TextUtils.h
|   `-- UserAccount.h
`-- src/
    |-- Appointment.cpp
    |-- AuthService.cpp
    |-- DataStore.cpp
    |-- DateTime.cpp
    |-- Doctor.cpp
    |-- InputUtils.cpp
    |-- main.cpp
    |-- Patient.cpp
    |-- Person.cpp
    |-- Scheduler.cpp
    |-- TextUtils.cpp
    `-- UserAccount.cpp
```

## Build Instructions

From the project root on Windows PowerShell:

```powershell
.\build.ps1
```

On systems with `make` installed:

```bash
make
```

Manual compile from project root:

```powershell
if (!(Test-Path build)) { New-Item -ItemType Directory -Path build | Out-Null }
g++ -std=c++14 -Wall -Wextra -pedantic -Iinclude src\*.cpp -o build\hospital_scheduler.exe
```

If the terminal is inside the `src` folder:

```powershell
if (!(Test-Path ..\build)) { New-Item -ItemType Directory -Path ..\build | Out-Null }
g++ -std=c++14 -Wall -Wextra -pedantic -I..\include *.cpp -o ..\build\hospital_scheduler.exe
```

Do not compile only `main.cpp`; this project uses multiple `.cpp` files.

## Run Instructions

Windows PowerShell:

```powershell
.\build\hospital_scheduler.exe
```

With Makefile:

```bash
make run
```

## Data Files

The program uses pipe-separated text files:

- `data/doctors.txt`
- `data/patients.txt`
- `data/appointments.txt`
- `data/users.txt`

Do not type the `|` character in user input because it is used as the file delimiter.

## UML Class Diagram

The UML diagram is included in:

- `docs/uml.md`
- `docs/uml.mmd`

## Final Submission Checklist

- GitHub repository link is ready
- All four members have visible commits
- README has build/run instructions
- UML diagram is included in `docs/`
- Program builds successfully
- Login and signup work
- Role-based menus work
- Appointments save and reload correctly
- Data files are included
