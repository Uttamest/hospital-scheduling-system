$ErrorActionPreference = "Stop"

if (!(Test-Path -LiteralPath "build")) {
    New-Item -ItemType Directory -Path "build" | Out-Null
}

g++ -std=c++14 -Wall -Wextra -pedantic -Iinclude src\*.cpp -o build\hospital_scheduler.exe

Write-Host "Built build\hospital_scheduler.exe"
