#ifndef AUTH_SERVICE_H
#define AUTH_SERVICE_H

#include "UserAccount.h"

#include <iosfwd>
#include <string>
#include <vector>

using namespace std;

class AuthService {
private:
    string usersFile;
    vector<UserAccount> users;

    int nextUserId() const;
    const UserAccount* findByUsername(const string& username) const;
    string hashPassword(const string& username, const string& password) const;
    string normalizeUsername(const string& username) const;
    void seedDefaultAdminIfNeeded();

public:
    explicit AuthService(const string& usersFile = "data/users.txt");

    void load();
    void save() const;

    UserAccount login(const string& username, const string& password) const;

    void validateNewCredentials(const string& username, const string& password) const;
    int registerUser(const string& username,
                     const string& password,
                     UserRole role,
                     int linkedPersonId);
    int registerPatient(const string& username, const string& password, int patientId);

    bool usernameExists(const string& username) const;
    bool linkedAccountExists(UserRole role, int linkedPersonId) const;
    void listUsers(ostream& out) const;
};

#endif
