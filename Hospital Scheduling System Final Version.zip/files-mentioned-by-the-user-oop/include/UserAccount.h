#ifndef USER_ACCOUNT_H
#define USER_ACCOUNT_H

#include <iosfwd>
#include <string>

using namespace std;

enum class UserRole {
    Admin,
    Receptionist,
    Doctor,
    Patient
};

string roleToString(UserRole role);
UserRole roleFromString(const string& role);

class UserAccount {
private:
    int id;
    string username;
    string passwordHash;
    UserRole role;
    int linkedPersonId;
    bool active;

public:
    UserAccount();
    UserAccount(int id,
                const string& username,
                const string& passwordHash,
                UserRole role,
                int linkedPersonId,
                bool active = true);

    int getId() const;
    const string& getUsername() const;
    const string& getPasswordHash() const;
    UserRole getRole() const;
    int getLinkedPersonId() const;
    bool isActive() const;

    bool isAdmin() const;
    bool isReceptionist() const;
    bool isDoctor() const;
    bool isPatient() const;

    void printSummary(ostream& out) const;
    string serialize() const;

    static UserAccount deserialize(const string& line);
};

#endif
