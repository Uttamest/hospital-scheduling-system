#ifndef INPUT_UTILS_H
#define INPUT_UTILS_H

#include <string>

using namespace std;

namespace input {
    string readLine(const string& prompt);
    string readRequiredLine(const string& prompt);
    int readInt(const string& prompt, int minValue, int maxValue);
    string readDate(const string& prompt);
    string readTime(const string& prompt);
    void pause();
}

#endif
