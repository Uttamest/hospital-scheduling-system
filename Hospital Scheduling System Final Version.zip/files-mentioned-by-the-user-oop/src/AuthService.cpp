#include "AuthService.h"

#include "HospitalException.h"
#include "TextUtils.h"

#include <cctype>
#include <fstream>
#include <iomanip>
#include <ostream>
#include <sstream>

using namespace std;

AuthService::AuthService(const string& usersFile)
    : usersFile(usersFile) {}

void AuthService::load() {
    users.clear();

    ifstream input(usersFile.c_str());
    if (!input) {
        seedDefaultAdminIfNeeded();
        save();
        return;
    }

    string line;
    int lineNumber = 0;
    while (getline(input, line)) {
        ++lineNumber;
        if (text::trim(line).empty()) {
            continue;
        }

        try {
            users.push_back(UserAccount::deserialize(line));
        } catch (const HospitalException& error) {
            ostringstream message;
            message << "Could not load " << usersFile << " line " << lineNumber << ": " << error.what();
            throw HospitalException(message.str());
        }
    }

    seedDefaultAdminIfNeeded();
}

void AuthService::save() const {
    ofstream output(usersFile.c_str());
    if (!output) {
        throw HospitalException("Could not write " + usersFile + ".");
    }

    for (vector<UserAccount>::const_iterator it = users.begin(); it != users.end(); ++it) {
        output << it->serialize() << '\n';
    }
}

UserAccount AuthService::login(const string& username, const string& password) const {
    const string normalizedUsername = normalizeUsername(username);
    const UserAccount* account = findByUsername(normalizedUsername);
    if (account == nullptr) {
        throw NotFoundException("No account exists for that username.");
    }
    if (!account->isActive()) {
        throw ValidationException("This account is disabled.");
    }
    if (account->getPasswordHash() != hashPassword(normalizedUsername, password)) {
        throw ValidationException("Incorrect password.");
    }

    return *account;
}

void AuthService::validateNewCredentials(const string& username, const string& password) const {
    const string normalizedUsername = normalizeUsername(username);
    if (normalizedUsername.length() < 3 || normalizedUsername.length() > 20) {
        throw ValidationException("Username must be 3 to 20 characters long.");
    }

    for (string::const_iterator it = normalizedUsername.begin(); it != normalizedUsername.end(); ++it) {
        const unsigned char ch = static_cast<unsigned char>(*it);
        if (!isalnum(ch) && *it != '_' && *it != '.') {
            throw ValidationException("Username can contain only letters, numbers, underscore, or dot.");
        }
    }

    text::requireField(password, "Password");
    if (password.length() < 6) {
        throw ValidationException("Password must be at least 6 characters long.");
    }
    text::requireNoDelimiter(password, "Password");

    if (usernameExists(normalizedUsername)) {
        throw ValidationException("That username is already taken.");
    }
}

int AuthService::registerUser(const string& username,
                              const string& password,
                              UserRole role,
                              int linkedPersonId) {
    const string normalizedUsername = normalizeUsername(username);
    validateNewCredentials(normalizedUsername, password);

    if ((role == UserRole::Doctor || role == UserRole::Patient) && linkedPersonId <= 0) {
        throw ValidationException("Doctor and patient accounts must be linked to an existing person id.");
    }
    if ((role == UserRole::Admin || role == UserRole::Receptionist) && linkedPersonId != 0) {
        throw ValidationException("Admin and receptionist accounts should use linked id 0.");
    }
    if (linkedAccountExists(role, linkedPersonId)) {
        throw ValidationException("An account already exists for that linked person.");
    }

    const int id = nextUserId();
    users.push_back(UserAccount(id,
                                normalizedUsername,
                                hashPassword(normalizedUsername, password),
                                role,
                                linkedPersonId));
    return id;
}

int AuthService::registerPatient(const string& username, const string& password, int patientId) {
    return registerUser(username, password, UserRole::Patient, patientId);
}

bool AuthService::usernameExists(const string& username) const {
    return findByUsername(normalizeUsername(username)) != nullptr;
}

bool AuthService::linkedAccountExists(UserRole role, int linkedPersonId) const {
    if (linkedPersonId <= 0) {
        return false;
    }

    for (vector<UserAccount>::const_iterator it = users.begin(); it != users.end(); ++it) {
        if (it->getRole() == role && it->getLinkedPersonId() == linkedPersonId) {
            return true;
        }
    }
    return false;
}

void AuthService::listUsers(ostream& out) const {
    out << "\nUser Accounts\n";
    out << "-------------\n";
    if (users.empty()) {
        out << "No user accounts found.\n";
        return;
    }

    for (vector<UserAccount>::const_iterator it = users.begin(); it != users.end(); ++it) {
        it->printSummary(out);
    }
}

int AuthService::nextUserId() const {
    int maxId = 0;
    for (vector<UserAccount>::const_iterator it = users.begin(); it != users.end(); ++it) {
        if (it->getId() > maxId) {
            maxId = it->getId();
        }
    }
    return maxId + 1;
}

const UserAccount* AuthService::findByUsername(const string& username) const {
    const string normalizedUsername = normalizeUsername(username);
    for (vector<UserAccount>::const_iterator it = users.begin(); it != users.end(); ++it) {
        if (it->getUsername() == normalizedUsername) {
            return &(*it);
        }
    }
    return nullptr;
}

string AuthService::hashPassword(const string& username, const string& password) const {
    const string value = normalizeUsername(username) + ":" + password + ":HSS_AUTH_V1";
    unsigned long long hash = 1469598103934665603ULL;

    // Educational password hashing demo: the file stores hashes, not plain text passwords.
    for (string::const_iterator it = value.begin(); it != value.end(); ++it) {
        hash ^= static_cast<unsigned char>(*it);
        hash *= 1099511628211ULL;
    }

    ostringstream out;
    out << hex << hash;
    return out.str();
}

string AuthService::normalizeUsername(const string& username) const {
    string normalized = text::trim(username);
    for (string::iterator it = normalized.begin(); it != normalized.end(); ++it) {
        *it = static_cast<char>(tolower(static_cast<unsigned char>(*it)));
    }
    return normalized;
}

void AuthService::seedDefaultAdminIfNeeded() {
    if (!users.empty()) {
        return;
    }

    const string username = "admin";
    users.push_back(UserAccount(1,
                                username,
                                hashPassword(username, "Admin@123"),
                                UserRole::Admin,
                                0));
}
