#include "AuthService.h"
#include "HospitalException.h"
#include "InputUtils.h"
#include "Scheduler.h"

#include <iostream>

using namespace std;

namespace
{

    string readPasswordTwice()
    {
        const string password = input::readRequiredLine("Password: ");
        const string confirmPassword = input::readRequiredLine("Confirm password: ");
        if (password != confirmPassword)
        {
            throw ValidationException("Passwords do not match.");
        }
        return password;
    }

    void addDoctorFlow(Scheduler &scheduler)
    {
        cout << "\nAdd Doctor\n";
        cout << "----------\n";
        const string name = input::readRequiredLine("Name: ");
        const string phone = input::readRequiredLine("Phone: ");
        const string specialization = input::readRequiredLine("Specialization: ");

        const int id = scheduler.addDoctor(name, phone, specialization);
        scheduler.save();
        cout << "Doctor created with id #" << id << ".\n";
    }

    void addPatientFlow(Scheduler &scheduler)
    {
        cout << "\nAdd Patient\n";
        cout << "-----------\n";
        const string name = input::readRequiredLine("Name: ");
        const string phone = input::readRequiredLine("Phone: ");
        const int age = input::readInt("Age: ", 0, 130);
        const string medicalNote = input::readLine("Medical note (optional): ");

        const int id = scheduler.addPatient(name, phone, age, medicalNote);
        scheduler.save();
        cout << "Patient created with id #" << id << ".\n";
    }

    void patientSignupFlow(AuthService &auth, Scheduler &scheduler)
    {
        cout << "\nPatient Sign Up\n";
        cout << "---------------\n";
        const string username = input::readRequiredLine("Choose username: ");
        const string password = readPasswordTwice();

        // Validate account details before creating the patient record.
        auth.validateNewCredentials(username, password);

        cout << "\nPatient Profile\n";
        cout << "---------------\n";
        const string name = input::readRequiredLine("Full name: ");
        const string phone = input::readRequiredLine("Phone: ");
        const int age = input::readInt("Age: ", 0, 130);
        const string medicalNote = input::readLine("Medical note (optional): ");

        const int patientId = scheduler.addPatient(name, phone, age, medicalNote);
        const int userId = auth.registerPatient(username, password, patientId);

        scheduler.save();
        auth.save();

        cout << "Signup complete. Patient id #" << patientId
             << " is linked to user account #" << userId << ".\n";
    }

    UserAccount loginFlow(const AuthService &auth)
    {
        cout << "\nLogin\n";
        cout << "-----\n";
        const string username = input::readRequiredLine("Username: ");
        const string password = input::readRequiredLine("Password: ");
        UserAccount account = auth.login(username, password);

        cout << "Welcome, " << account.getUsername()
             << " (" << roleToString(account.getRole()) << ").\n";
        return account;
    }

    void createAppointmentFlow(Scheduler &scheduler)
    {
        if (!scheduler.hasDoctors() || !scheduler.hasPatients())
        {
            cout << "\nCreate at least one doctor and one patient before scheduling appointments.\n";
            return;
        }

        scheduler.listDoctors(cout);
        scheduler.listPatients(cout);

        cout << "\nCreate Appointment\n";
        cout << "------------------\n";
        const int doctorId = input::readInt("Doctor id: ", 1, 100000000);
        const int patientId = input::readInt("Patient id: ", 1, 100000000);
        const string date = input::readDate("Date (YYYY-MM-DD): ");
        const string time = input::readTime("Time (HH:MM): ");
        const string reason = input::readRequiredLine("Reason: ");

        const int id = scheduler.createAppointment(doctorId, patientId, date, time, reason);
        scheduler.save();
        cout << "Appointment created with id #" << id << ".\n";
    }

    void createPatientAppointmentFlow(Scheduler &scheduler, const UserAccount &account)
    {
        const int patientId = account.getLinkedPersonId();
        if (!scheduler.patientExists(patientId))
        {
            throw NotFoundException("Your patient profile is not available. Please contact reception.");
        }
        if (!scheduler.hasDoctors())
        {
            cout << "\nNo doctors are available for booking yet.\n";
            return;
        }

        scheduler.listDoctors(cout);

        cout << "\nBook My Appointment\n";
        cout << "-------------------\n";
        const int doctorId = input::readInt("Doctor id: ", 1, 100000000);
        const string date = input::readDate("Date (YYYY-MM-DD): ");
        const string time = input::readTime("Time (HH:MM): ");
        const string reason = input::readRequiredLine("Reason: ");

        const int id = scheduler.createAppointment(doctorId, patientId, date, time, reason);
        scheduler.save();
        cout << "Your appointment was booked with id #" << id << ".\n";
    }

    void cancelAppointmentFlow(Scheduler &scheduler)
    {
        if (!scheduler.hasAppointments())
        {
            cout << "\nThere are no appointments to cancel.\n";
            return;
        }

        scheduler.listAppointments(cout);
        const int appointmentId = input::readInt("\nAppointment id to cancel: ", 1, 100000000);
        scheduler.cancelAppointment(appointmentId);
        scheduler.save();
        cout << "Appointment #" << appointmentId << " was cancelled.\n";
    }

    void cancelPatientAppointmentFlow(Scheduler &scheduler, const UserAccount &account)
    {
        const int patientId = account.getLinkedPersonId();
        scheduler.listPatientSchedule(patientId, cout);
        const int appointmentId = input::readInt("\nAppointment id to cancel: ", 1, 100000000);
        scheduler.cancelPatientAppointment(appointmentId, patientId);
        scheduler.save();
        cout << "Your appointment #" << appointmentId << " was cancelled.\n";
    }

    void doctorScheduleFlow(const Scheduler &scheduler)
    {
        scheduler.listDoctors(cout);
        const int doctorId = input::readInt("\nDoctor id: ", 1, 100000000);
        scheduler.listDoctorSchedule(doctorId, cout);
    }

    void patientScheduleFlow(const Scheduler &scheduler)
    {
        scheduler.listPatients(cout);
        const int patientId = input::readInt("\nPatient id: ", 1, 100000000);
        scheduler.listPatientSchedule(patientId, cout);
    }

    void doctorMenu(Scheduler &scheduler)
    {
        while (true)
        {
            cout << "\nDoctor Management\n";
            cout << "-----------------\n";
            cout << "1. Add doctor\n";
            cout << "2. View doctors\n";
            cout << "0. Back\n";

            const int choice = input::readInt("Choose: ", 0, 2);
            try
            {
                switch (choice)
                {
                case 1:
                    addDoctorFlow(scheduler);
                    input::pause();
                    break;
                case 2:
                    scheduler.listDoctors(cout);
                    input::pause();
                    break;
                case 0:
                    return;
                }
            }
            catch (const HospitalException &error)
            {
                cout << "Error: " << error.what() << '\n';
                input::pause();
            }
        }
    }

    void patientMenu(Scheduler &scheduler)
    {
        while (true)
        {
            cout << "\nPatient Records\n";
            cout << "---------------\n";
            cout << "1. Add patient\n";
            cout << "2. View patients\n";
            cout << "0. Back\n";

            const int choice = input::readInt("Choose: ", 0, 2);
            try
            {
                switch (choice)
                {
                case 1:
                    addPatientFlow(scheduler);
                    input::pause();
                    break;
                case 2:
                    scheduler.listPatients(cout);
                    input::pause();
                    break;
                case 0:
                    return;
                }
            }
            catch (const HospitalException &error)
            {
                cout << "Error: " << error.what() << '\n';
                input::pause();
            }
        }
    }

    void appointmentMenu(Scheduler &scheduler)
    {
        while (true)
        {
            cout << "\nAppointment Desk\n";
            cout << "----------------\n";
            cout << "1. Create appointment\n";
            cout << "2. Cancel appointment\n";
            cout << "3. View all appointments\n";
            cout << "4. View doctor schedule\n";
            cout << "5. View patient schedule\n";
            cout << "0. Back\n";

            const int choice = input::readInt("Choose: ", 0, 5);
            try
            {
                switch (choice)
                {
                case 1:
                    createAppointmentFlow(scheduler);
                    input::pause();
                    break;
                case 2:
                    cancelAppointmentFlow(scheduler);
                    input::pause();
                    break;
                case 3:
                    scheduler.listAppointments(cout);
                    input::pause();
                    break;
                case 4:
                    doctorScheduleFlow(scheduler);
                    input::pause();
                    break;
                case 5:
                    patientScheduleFlow(scheduler);
                    input::pause();
                    break;
                case 0:
                    return;
                }
            }
            catch (const HospitalException &error)
            {
                cout << "Error: " << error.what() << '\n';
                input::pause();
            }
        }
    }

    void userAccountMenu(AuthService &auth, const Scheduler &scheduler)
    {
        while (true)
        {
            cout << "\nUser Account Management\n";
            cout << "-----------------------\n";
            cout << "1. List user accounts\n";
            cout << "2. Create staff/doctor/patient login\n";
            cout << "0. Back\n";

            const int choice = input::readInt("Choose: ", 0, 2);
            try
            {
                if (choice == 1)
                {
                    auth.listUsers(cout);
                    input::pause();
                }
                else if (choice == 2)
                {
                    cout << "\nCreate User Account\n";
                    cout << "-------------------\n";
                    cout << "1. Admin\n";
                    cout << "2. Receptionist\n";
                    cout << "3. Doctor\n";
                    cout << "4. Patient\n";
                    const int roleChoice = input::readInt("Role: ", 1, 4);

                    UserRole role = UserRole::Patient;
                    int linkedPersonId = 0;
                    if (roleChoice == 1)
                    {
                        role = UserRole::Admin;
                    }
                    else if (roleChoice == 2)
                    {
                        role = UserRole::Receptionist;
                    }
                    else if (roleChoice == 3)
                    {
                        role = UserRole::Doctor;
                        scheduler.listDoctors(cout);
                        linkedPersonId = input::readInt("\nLinked doctor id: ", 1, 100000000);
                        if (!scheduler.doctorExists(linkedPersonId))
                        {
                            throw NotFoundException("That doctor id does not exist.");
                        }
                    }
                    else
                    {
                        role = UserRole::Patient;
                        scheduler.listPatients(cout);
                        linkedPersonId = input::readInt("\nLinked patient id: ", 1, 100000000);
                        if (!scheduler.patientExists(linkedPersonId))
                        {
                            throw NotFoundException("That patient id does not exist.");
                        }
                    }

                    const string username = input::readRequiredLine("Username: ");
                    const string password = readPasswordTwice();
                    const int id = auth.registerUser(username, password, role, linkedPersonId);
                    auth.save();
                    cout << "User account #" << id << " created.\n";
                    input::pause();
                }
                else
                {
                    return;
                }
            }
            catch (const HospitalException &error)
            {
                cout << "Error: " << error.what() << '\n';
                input::pause();
            }
        }
    }

    void staffMenu(Scheduler &scheduler, AuthService &auth, const UserAccount &account)
    {
        const bool admin = account.isAdmin();
        while (true)
        {
            cout << "\n" << (admin ? "Administrator Console" : "Reception Console") << "\n";
            cout << (admin ? "---------------------" : "-----------------") << "\n";
            cout << "Logged in as: " << account.getUsername()
                 << " (" << roleToString(account.getRole()) << ")\n";
            cout << "1. Doctors\n";
            cout << "2. Patients\n";
            cout << "3. Appointments\n";
            if (admin)
            {
                cout << "4. User accounts\n";
                cout << "5. View all people (runtime polymorphism demo)\n";
                cout << "6. Save data\n";
                cout << "0. Logout\n";
            }
            else
            {
                cout << "4. View all people (runtime polymorphism demo)\n";
                cout << "5. Save data\n";
                cout << "0. Logout\n";
            }

            const int maxChoice = admin ? 6 : 5;
            const int choice = input::readInt("Choose: ", 0, maxChoice);
            try
            {
                if (choice == 1)
                {
                    doctorMenu(scheduler);
                }
                else if (choice == 2)
                {
                    patientMenu(scheduler);
                }
                else if (choice == 3)
                {
                    appointmentMenu(scheduler);
                }
                else if (admin && choice == 4)
                {
                    userAccountMenu(auth, scheduler);
                }
                else if ((admin && choice == 5) || (!admin && choice == 4))
                {
                    scheduler.listAllPeoplePolymorphic(cout);
                    input::pause();
                }
                else if ((admin && choice == 6) || (!admin && choice == 5))
                {
                    scheduler.save();
                    auth.save();
                    cout << "Data saved.\n";
                    input::pause();
                }
                else
                {
                    return;
                }
            }
            catch (const HospitalException &error)
            {
                cout << "Error: " << error.what() << '\n';
                input::pause();
            }
        }
    }

    void doctorPortal(Scheduler &scheduler, const UserAccount &account)
    {
        while (true)
        {
            cout << "\nDoctor Portal\n";
            cout << "-------------\n";
            cout << "Logged in as: " << account.getUsername() << '\n';
            cout << "1. View my schedule\n";
            cout << "2. View doctor directory\n";
            cout << "0. Logout\n";

            const int choice = input::readInt("Choose: ", 0, 2);
            try
            {
                if (choice == 1)
                {
                    scheduler.listDoctorSchedule(account.getLinkedPersonId(), cout);
                    input::pause();
                }
                else if (choice == 2)
                {
                    scheduler.listDoctors(cout);
                    input::pause();
                }
                else
                {
                    return;
                }
            }
            catch (const HospitalException &error)
            {
                cout << "Error: " << error.what() << '\n';
                input::pause();
            }
        }
    }

    void patientPortal(Scheduler &scheduler, const UserAccount &account)
    {
        while (true)
        {
            cout << "\nPatient Portal\n";
            cout << "--------------\n";
            cout << "Logged in as: " << account.getUsername() << '\n';
            cout << "1. Book appointment\n";
            cout << "2. Cancel my appointment\n";
            cout << "3. View my schedule\n";
            cout << "4. View doctor directory\n";
            cout << "0. Logout\n";

            const int choice = input::readInt("Choose: ", 0, 4);
            try
            {
                if (choice == 1)
                {
                    createPatientAppointmentFlow(scheduler, account);
                    input::pause();
                }
                else if (choice == 2)
                {
                    cancelPatientAppointmentFlow(scheduler, account);
                    input::pause();
                }
                else if (choice == 3)
                {
                    scheduler.listPatientSchedule(account.getLinkedPersonId(), cout);
                    input::pause();
                }
                else if (choice == 4)
                {
                    scheduler.listDoctors(cout);
                    input::pause();
                }
                else
                {
                    return;
                }
            }
            catch (const HospitalException &error)
            {
                cout << "Error: " << error.what() << '\n';
                input::pause();
            }
        }
    }

    void routeAuthenticatedUser(Scheduler &scheduler, AuthService &auth, const UserAccount &account)
    {
        if (account.isAdmin() || account.isReceptionist())
        {
            staffMenu(scheduler, auth, account);
        }
        else if (account.isDoctor())
        {
            doctorPortal(scheduler, account);
        }
        else
        {
            patientPortal(scheduler, account);
        }
    }

}

int main()
{
    Scheduler scheduler;
    AuthService auth;

    try
    {
        // Load saved records before showing the login screen.
        scheduler.load();
        auth.load();
        cout << "Hospital Scheduling System\n";
        cout << "Secure CLI edition with role-based access.\n";
        cout << "Data loaded from the data folder.\n";
    }
    catch (const HospitalException &error)
    {
        cout << "Startup warning: " << error.what() << '\n';
        cout << "Please fix the data file before running the program again.\n";
        return 1;
    }

    bool running = true;
    while (running)
    {
        cout << "\nWelcome\n";
        cout << "-------\n";
        cout << "1. Login\n";
        cout << "2. Patient sign up\n";
        cout << "0. Exit\n";

        try
        {
            const int choice = input::readInt("Choose: ", 0, 2);
            if (choice == 1)
            {
                const UserAccount account = loginFlow(auth);
                input::pause();
                routeAuthenticatedUser(scheduler, auth, account);
            }
            else if (choice == 2)
            {
                patientSignupFlow(auth, scheduler);
                input::pause();
            }
            else
            {
                running = false;
            }
        }
        catch (const HospitalException &error)
        {
            cout << "Error: " << error.what() << '\n';
            if (!cin)
            {
                running = false;
            }
            else
            {
                input::pause();
            }
        }
    }

    try
    {
        scheduler.save();
        auth.save();
        cout << "Goodbye. Data saved.\n";
    }
    catch (const HospitalException &error)
    {
        cout << "Exit warning: " << error.what() << '\n';
    }

    return 0;
}
