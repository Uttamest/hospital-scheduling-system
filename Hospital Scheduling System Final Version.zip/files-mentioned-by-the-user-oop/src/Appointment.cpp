#include "Appointment.h"

#include "DateTime.h"
#include "HospitalException.h"
#include "TextUtils.h"

#include <ostream>
#include <sstream>

using namespace std;

string statusToString(AppointmentStatus status) {
    switch (status) {
        case AppointmentStatus::Scheduled:
            return "Scheduled";
        case AppointmentStatus::Cancelled:
            return "Cancelled";
    }

    return "Scheduled";
}

AppointmentStatus statusFromString(const string& status) {
    const string trimmed = text::trim(status);
    if (trimmed == "Scheduled") {
        return AppointmentStatus::Scheduled;
    }
    if (trimmed == "Cancelled") {
        return AppointmentStatus::Cancelled;
    }

    throw ValidationException("Unknown appointment status: " + status);
}

Appointment::Appointment(int id,
                         int doctorId,
                         int patientId,
                         const string& date,
                         const string& time,
                         const string& reason,
                         AppointmentStatus status)
    : id(id),
      doctorId(doctorId),
      patientId(patientId),
      date(text::trim(date)),
      time(text::trim(time)),
      reason(text::trim(reason)),
      status(status) {
    if (id <= 0) {
        throw ValidationException("Appointment id must be positive.");
    }
    if (doctorId <= 0 || patientId <= 0) {
        throw ValidationException("Doctor id and patient id must be positive.");
    }

    DateTime::requireValidDate(this->date);
    DateTime::requireValidTime(this->time);
    text::requireField(this->reason, "Appointment reason");
}

int Appointment::getId() const {
    return id;
}

int Appointment::getDoctorId() const {
    return doctorId;
}

int Appointment::getPatientId() const {
    return patientId;
}

const string& Appointment::getDate() const {
    return date;
}

const string& Appointment::getTime() const {
    return time;
}

const string& Appointment::getReason() const {
    return reason;
}

AppointmentStatus Appointment::getStatus() const {
    return status;
}

bool Appointment::isActive() const {
    return status == AppointmentStatus::Scheduled;
}

string Appointment::dateTimeKey() const {
    return DateTime::key(date, time);
}

void Appointment::cancel() {
    if (status == AppointmentStatus::Cancelled) {
        throw ValidationException("Appointment is already cancelled.");
    }
    status = AppointmentStatus::Cancelled;
}

void Appointment::printSummary(ostream& out, const string& doctorName, const string& patientName) const {
    out << "[Appointment #" << id << "] "
        << date << ' ' << time
        << " | Doctor: " << doctorName
        << " | Patient: " << patientName
        << " | Reason: " << reason
        << " | Status: " << statusToString(status) << '\n';
}

string Appointment::serialize() const {
    ostringstream out;
    out << id << '|'
        << doctorId << '|'
        << patientId << '|'
        << date << '|'
        << time << '|'
        << reason << '|'
        << statusToString(status);
    return out.str();
}

Appointment Appointment::deserialize(const string& line) {
    const vector<string> parts = text::split(line, '|');
    if (parts.size() != 7) {
        throw ValidationException("Appointment record must have 7 fields.");
    }

    return Appointment(text::toInt(parts[0], "Appointment id"),
                       text::toInt(parts[1], "Doctor id"),
                       text::toInt(parts[2], "Patient id"),
                       parts[3],
                       parts[4],
                       parts[5],
                       statusFromString(parts[6]));
}
