#include "UserAccount.h"

#include "HospitalException.h"
#include "TextUtils.h"

#include <ostream>
#include <sstream>

using namespace std;

string roleToString(UserRole role) {
    switch (role) {
        case UserRole::Admin:
            return "Admin";
        case UserRole::Receptionist:
            return "Receptionist";
        case UserRole::Doctor:
            return "Doctor";
        case UserRole::Patient:
            return "Patient";
    }

    return "Patient";
}

UserRole roleFromString(const string& role) {
    const string trimmed = text::trim(role);
    if (trimmed == "Admin") {
        return UserRole::Admin;
    }
    if (trimmed == "Receptionist") {
        return UserRole::Receptionist;
    }
    if (trimmed == "Doctor") {
        return UserRole::Doctor;
    }
    if (trimmed == "Patient") {
        return UserRole::Patient;
    }

    throw ValidationException("Unknown user role: " + role);
}

UserAccount::UserAccount()
    : id(0),
      role(UserRole::Patient),
      linkedPersonId(0),
      active(false) {}

UserAccount::UserAccount(int id,
                         const string& username,
                         const string& passwordHash,
                         UserRole role,
                         int linkedPersonId,
                         bool active)
    : id(id),
      role(role),
      linkedPersonId(linkedPersonId),
      active(active) {
    if (id <= 0) {
        throw ValidationException("User id must be positive.");
    }
    if (linkedPersonId < 0) {
        throw ValidationException("Linked person id cannot be negative.");
    }

    text::requireField(username, "Username");
    text::requireField(passwordHash, "Password hash");

    this->username = text::trim(username);
    this->passwordHash = text::trim(passwordHash);
}

int UserAccount::getId() const {
    return id;
}

const string& UserAccount::getUsername() const {
    return username;
}

const string& UserAccount::getPasswordHash() const {
    return passwordHash;
}

UserRole UserAccount::getRole() const {
    return role;
}

int UserAccount::getLinkedPersonId() const {
    return linkedPersonId;
}

bool UserAccount::isActive() const {
    return active;
}

bool UserAccount::isAdmin() const {
    return role == UserRole::Admin;
}

bool UserAccount::isReceptionist() const {
    return role == UserRole::Receptionist;
}

bool UserAccount::isDoctor() const {
    return role == UserRole::Doctor;
}

bool UserAccount::isPatient() const {
    return role == UserRole::Patient;
}

void UserAccount::printSummary(ostream& out) const {
    out << "[User #" << id << "] "
        << username
        << " | Role: " << roleToString(role)
        << " | Linked ID: " << linkedPersonId
        << " | Status: " << (active ? "Active" : "Disabled") << '\n';
}

string UserAccount::serialize() const {
    ostringstream out;
    out << id << '|'
        << username << '|'
        << passwordHash << '|'
        << roleToString(role) << '|'
        << linkedPersonId << '|'
        << (active ? "Active" : "Disabled");
    return out.str();
}

UserAccount UserAccount::deserialize(const string& line) {
    const vector<string> parts = text::split(line, '|');
    if (parts.size() != 6) {
        throw ValidationException("User account record must have 6 fields.");
    }

    const string status = text::trim(parts[5]);
    bool active = false;
    if (status == "Active") {
        active = true;
    } else if (status == "Disabled") {
        active = false;
    } else {
        throw ValidationException("User status must be Active or Disabled.");
    }

    return UserAccount(text::toInt(parts[0], "User id"),
                       parts[1],
                       parts[2],
                       roleFromString(parts[3]),
                       text::toInt(parts[4], "Linked person id"),
                       active);
}
