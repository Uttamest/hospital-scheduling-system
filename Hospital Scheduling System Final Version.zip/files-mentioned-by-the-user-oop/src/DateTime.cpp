#include "DateTime.h"

#include "HospitalException.h"

#include <cctype>
#include <cstdlib>

using namespace std;

namespace {

bool hasDigits(const string& value, size_t begin, size_t count) {
    for (size_t index = begin; index < begin + count; ++index) {
        if (!isdigit(static_cast<unsigned char>(value[index]))) {
            return false;
        }
    }
    return true;
}

int parseNumber(const string& value, size_t begin, size_t count) {
    return atoi(value.substr(begin, count).c_str());
}

}

bool DateTime::isValidDate(const string& date) {
    // Keep dates strict so file data and user input stay predictable.
    if (date.size() != 10 || date[4] != '-' || date[7] != '-') {
        return false;
    }
    if (!hasDigits(date, 0, 4) || !hasDigits(date, 5, 2) || !hasDigits(date, 8, 2)) {
        return false;
    }

    const int year = parseNumber(date, 0, 4);
    const int month = parseNumber(date, 5, 2);
    const int day = parseNumber(date, 8, 2);

    if (year < 1900 || year > 2100 || month < 1 || month > 12) {
        return false;
    }

    return day >= 1 && day <= daysInMonth(year, month);
}

bool DateTime::isValidTime(const string& time) {
    // The CLI uses 24-hour HH:MM times for all appointments.
    if (time.size() != 5 || time[2] != ':') {
        return false;
    }
    if (!hasDigits(time, 0, 2) || !hasDigits(time, 3, 2)) {
        return false;
    }

    const int hour = parseNumber(time, 0, 2);
    const int minute = parseNumber(time, 3, 2);
    return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;
}

void DateTime::requireValidDate(const string& date) {
    if (!isValidDate(date)) {
        throw ValidationException("Date must use the format YYYY-MM-DD and be a real calendar date.");
    }
}

void DateTime::requireValidTime(const string& time) {
    if (!isValidTime(time)) {
        throw ValidationException("Time must use the format HH:MM in 24-hour time.");
    }
}

string DateTime::key(const string& date, const string& time) {
    return date + " " + time;
}

bool DateTime::isLeapYear(int year) {
    return (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
}

int DateTime::daysInMonth(int year, int month) {
    static const int days[] = {
        0, 31, 28, 31, 30, 31, 30,
        31, 31, 30, 31, 30, 31
    };

    if (month == 2 && isLeapYear(year)) {
        return 29;
    }

    return days[month];
}
